-- phpMyAdmin SQL Dump
-- version 4.0.10
-- http://www.phpmyadmin.net
--
-- โฮสต์: localhost
-- เวลาในการสร้าง: 13 ม.ค. 2017  10:45น.
-- เวอร์ชั่นของเซิร์ฟเวอร์: 5.1.71
-- รุ่นของ PHP: 5.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- ฐานข้อมูล: `tracker`
--

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `app_access_groups`
--

DROP TABLE IF EXISTS `app_access_groups`;
CREATE TABLE IF NOT EXISTS `app_access_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `is_default` tinyint(1) DEFAULT NULL,
  `is_ldap_default` tinyint(1) DEFAULT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- dump ตาราง `app_access_groups`
--

INSERT INTO `app_access_groups` (`id`, `name`, `is_default`, `is_ldap_default`, `sort_order`) VALUES
(4, 'Manager', 1, 0, 2),
(5, 'Developer', 0, 0, 1),
(6, 'Client', 0, 0, 0);

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `app_attachments`
--

DROP TABLE IF EXISTS `app_attachments`;
CREATE TABLE IF NOT EXISTS `app_attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_token` varchar(64) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `date_added` date NOT NULL,
  `container` varchar(16) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `app_choices_values`
--

DROP TABLE IF EXISTS `app_choices_values`;
CREATE TABLE IF NOT EXISTS `app_choices_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `items_id` int(11) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=839 ;

--
-- dump ตาราง `app_choices_values`
--

INSERT INTO `app_choices_values` (`id`, `entities_id`, `items_id`, `fields_id`, `value`) VALUES
(79, 22, 3, 167, 44),
(80, 22, 3, 169, 48),
(81, 22, 3, 170, 53),
(82, 22, 3, 171, 21),
(83, 22, 4, 167, 42),
(84, 22, 4, 169, 47),
(85, 22, 4, 170, 55),
(86, 22, 4, 171, 20),
(96, 21, 3, 156, 34),
(97, 21, 3, 161, 21),
(98, 21, 3, 161, 26),
(99, 21, 3, 161, 23),
(100, 21, 3, 157, 37),
(117, 22, 5, 167, 42),
(118, 22, 5, 169, 52),
(119, 22, 5, 170, 55),
(120, 22, 5, 171, 25),
(121, 21, 1, 156, 34),
(122, 21, 1, 161, 21),
(123, 21, 1, 161, 24),
(124, 21, 1, 161, 22),
(125, 21, 1, 161, 20),
(126, 21, 1, 161, 26),
(127, 21, 1, 161, 23),
(128, 21, 1, 161, 25),
(129, 21, 1, 157, 38),
(130, 21, 2, 156, 34),
(131, 21, 2, 161, 21),
(132, 21, 2, 161, 24),
(133, 21, 2, 161, 22),
(134, 21, 2, 161, 20),
(135, 21, 2, 161, 26),
(136, 21, 2, 161, 23),
(137, 21, 2, 161, 25),
(138, 21, 2, 157, 38),
(139, 21, 4, 156, 34),
(140, 21, 4, 161, 21),
(141, 21, 4, 161, 24),
(142, 21, 4, 161, 22),
(143, 21, 4, 161, 20),
(144, 21, 4, 161, 26),
(145, 21, 4, 161, 23),
(146, 21, 4, 161, 25),
(147, 21, 4, 157, 37),
(154, 22, 6, 167, 45),
(155, 22, 6, 169, 46),
(156, 22, 6, 170, 55),
(157, 22, 6, 171, 24),
(158, 22, 6, 171, 20),
(159, 22, 6, 171, 25),
(166, 21, 5, 156, 34),
(167, 21, 5, 161, 22),
(168, 21, 5, 161, 20),
(169, 21, 5, 161, 19),
(170, 21, 5, 157, 37),
(179, 22, 7, 167, 42),
(180, 22, 7, 169, 50),
(181, 22, 7, 170, 53),
(182, 22, 7, 171, 22),
(197, 22, 2, 167, 44),
(198, 22, 2, 169, 49),
(199, 22, 2, 170, 55),
(200, 22, 2, 171, 20),
(201, 22, 1, 167, 44),
(202, 22, 1, 169, 49),
(203, 22, 1, 170, 55),
(204, 22, 1, 171, 20),
(233, 22, 12, 167, 42),
(235, 22, 12, 170, 55),
(236, 22, 12, 171, 22),
(237, 22, 13, 167, 42),
(239, 22, 13, 170, 55),
(240, 22, 13, 171, 22),
(256, 22, 15, 167, 42),
(258, 22, 15, 170, 55),
(262, 22, 16, 167, 42),
(265, 22, 16, 171, 22),
(278, 22, 11, 167, 42),
(279, 22, 11, 169, 46),
(280, 22, 11, 170, 55),
(281, 22, 11, 171, 22),
(293, 21, 6, 156, 34),
(294, 21, 6, 161, 21),
(295, 21, 6, 161, 22),
(296, 21, 6, 161, 20),
(297, 21, 6, 161, 23),
(298, 21, 6, 161, 19),
(299, 21, 6, 157, 37),
(313, 21, 7, 156, 34),
(314, 21, 7, 161, 22),
(315, 21, 7, 161, 20),
(316, 21, 7, 161, 19),
(317, 21, 7, 157, 37),
(328, 22, 18, 167, 42),
(329, 22, 18, 169, 49),
(330, 22, 18, 170, 54),
(331, 22, 18, 171, 22),
(344, 22, 9, 167, 42),
(345, 22, 9, 169, 49),
(346, 22, 9, 170, 55),
(347, 22, 9, 171, 20),
(380, 22, 24, 167, 44),
(382, 22, 24, 170, 55),
(383, 22, 24, 171, 22),
(384, 22, 10, 167, 43),
(386, 22, 10, 170, 55),
(387, 22, 10, 171, 22),
(388, 22, 23, 167, 42),
(389, 22, 23, 169, 49),
(390, 22, 23, 170, 53),
(391, 22, 23, 171, 20),
(400, 22, 8, 167, 42),
(401, 22, 8, 169, 49),
(402, 22, 8, 170, 53),
(403, 22, 8, 171, 22),
(404, 22, 25, 167, 44),
(406, 22, 25, 170, 53),
(407, 22, 25, 171, 22),
(408, 22, 26, 167, 44),
(410, 22, 26, 170, 53),
(411, 22, 26, 171, 22),
(412, 22, 25, 169, 49),
(413, 22, 19, 167, 42),
(414, 22, 19, 169, 49),
(415, 22, 19, 170, 53),
(416, 22, 19, 171, 20),
(417, 22, 20, 167, 42),
(418, 22, 20, 169, 49),
(419, 22, 20, 170, 53),
(420, 22, 20, 171, 20),
(421, 22, 21, 167, 42),
(422, 22, 21, 169, 49),
(423, 22, 21, 170, 53),
(424, 22, 21, 171, 20),
(425, 22, 22, 167, 42),
(426, 22, 22, 169, 49),
(427, 22, 22, 170, 53),
(428, 22, 22, 171, 20),
(429, 22, 27, 167, 42),
(432, 22, 27, 171, 22),
(435, 22, 12, 169, 49),
(436, 22, 13, 169, 49),
(437, 22, 10, 169, 48),
(438, 22, 26, 169, 49),
(440, 22, 24, 169, 49),
(441, 22, 16, 169, 49),
(442, 22, 16, 170, 55),
(443, 22, 27, 169, 49),
(444, 22, 27, 170, 53),
(445, 22, 15, 169, 49),
(446, 22, 14, 167, 42),
(447, 22, 14, 169, 48),
(448, 22, 14, 170, 55),
(449, 22, 14, 171, 22),
(450, 22, 28, 167, 44),
(452, 22, 28, 170, 55),
(453, 22, 28, 169, 49),
(459, 22, 17, 167, 42),
(460, 22, 17, 169, 48),
(461, 22, 17, 170, 55),
(462, 22, 17, 171, 22),
(548, 22, 38, 167, 42),
(549, 22, 38, 169, 46),
(550, 22, 38, 170, 55),
(557, 22, 35, 167, 42),
(559, 22, 35, 170, 55),
(609, 22, 41, 167, 42),
(610, 22, 41, 169, 49),
(611, 22, 41, 170, 55),
(612, 22, 41, 171, 22),
(617, 22, 30, 167, 42),
(618, 22, 30, 169, 49),
(619, 22, 30, 170, 55),
(620, 22, 30, 171, 22),
(625, 22, 33, 167, 42),
(626, 22, 33, 169, 49),
(627, 22, 33, 170, 55),
(628, 22, 33, 171, 20),
(629, 21, 8, 156, 34),
(630, 21, 8, 161, 22),
(631, 21, 8, 161, 20),
(632, 21, 8, 157, 37),
(641, 22, 34, 167, 42),
(642, 22, 34, 169, 49),
(643, 22, 34, 170, 55),
(644, 22, 34, 171, 20),
(653, 22, 31, 167, 42),
(654, 22, 31, 169, 49),
(655, 22, 31, 170, 55),
(656, 22, 31, 171, 22),
(663, 22, 40, 167, 42),
(664, 22, 40, 169, 49),
(665, 22, 40, 170, 55),
(666, 22, 40, 171, 22),
(667, 22, 32, 167, 42),
(668, 22, 32, 169, 49),
(669, 22, 32, 170, 55),
(670, 22, 32, 171, 22),
(675, 22, 42, 167, 42),
(676, 22, 42, 169, 49),
(677, 22, 42, 170, 55),
(678, 22, 42, 171, 22),
(691, 22, 43, 167, 42),
(692, 22, 43, 169, 46),
(693, 22, 43, 170, 55),
(694, 22, 43, 171, 22),
(699, 22, 44, 167, 42),
(700, 22, 44, 169, 52),
(701, 22, 44, 170, 55),
(702, 22, 44, 171, 22),
(706, 22, 45, 167, 42),
(707, 22, 45, 169, 46),
(708, 22, 45, 170, 55),
(709, 22, 45, 171, 22),
(710, 22, 45, 171, 20),
(711, 22, 37, 167, 42),
(712, 22, 37, 169, 49),
(713, 22, 37, 170, 55),
(714, 22, 37, 171, 20),
(718, 22, 47, 167, 42),
(719, 22, 47, 169, 46),
(720, 22, 47, 170, 55),
(721, 22, 47, 171, 22),
(722, 22, 47, 171, 20),
(723, 22, 48, 167, 42),
(724, 22, 48, 169, 46),
(725, 22, 48, 170, 55),
(726, 22, 48, 171, 22),
(727, 22, 49, 167, 42),
(728, 22, 49, 169, 46),
(729, 22, 49, 170, 55),
(730, 22, 49, 171, 22),
(731, 22, 39, 167, 42),
(732, 22, 39, 169, 49),
(733, 22, 39, 170, 55),
(734, 22, 39, 171, 22),
(738, 22, 50, 167, 42),
(739, 22, 50, 169, 46),
(740, 22, 50, 170, 55),
(746, 22, 51, 167, 42),
(747, 22, 51, 169, 46),
(748, 22, 51, 170, 55),
(749, 22, 51, 171, 22),
(760, 22, 53, 167, 42),
(761, 22, 53, 169, 46),
(762, 22, 53, 170, 55),
(763, 22, 53, 171, 22),
(764, 22, 53, 171, 20),
(765, 22, 35, 169, 49),
(766, 22, 52, 167, 42),
(767, 22, 52, 169, 52),
(768, 22, 52, 170, 55),
(769, 22, 52, 171, 22),
(770, 22, 52, 171, 20),
(771, 22, 54, 167, 42),
(772, 22, 54, 169, 46),
(773, 22, 54, 170, 55),
(774, 22, 54, 171, 22),
(775, 22, 54, 171, 20),
(776, 22, 55, 167, 42),
(777, 22, 55, 169, 46),
(778, 22, 55, 170, 55),
(779, 22, 55, 171, 22),
(780, 22, 55, 171, 20),
(781, 22, 46, 167, 42),
(782, 22, 46, 169, 49),
(783, 22, 46, 170, 55),
(784, 22, 46, 171, 20),
(800, 22, 57, 167, 42),
(801, 22, 57, 169, 46),
(802, 22, 57, 170, 55),
(803, 22, 57, 171, 22),
(804, 22, 57, 171, 20),
(810, 22, 56, 167, 42),
(811, 22, 56, 169, 49),
(812, 22, 56, 170, 55),
(813, 22, 56, 171, 22),
(814, 22, 56, 171, 20),
(815, 22, 36, 167, 42),
(816, 22, 36, 169, 49),
(817, 22, 36, 170, 55),
(818, 22, 36, 171, 22),
(819, 22, 36, 171, 20),
(820, 22, 29, 167, 42),
(821, 22, 29, 169, 49),
(822, 22, 29, 170, 55),
(823, 22, 29, 171, 20),
(832, 21, 9, 156, 34),
(833, 21, 9, 161, 22),
(834, 21, 9, 161, 20),
(835, 21, 9, 157, 37),
(836, 22, 58, 167, 42),
(837, 22, 58, 169, 46),
(838, 22, 58, 170, 55);

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `app_comments`
--

DROP TABLE IF EXISTS `app_comments`;
CREATE TABLE IF NOT EXISTS `app_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `items_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `description` text,
  `attachments` text NOT NULL,
  `date_added` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_created_by` (`created_by`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=32 ;

--
-- dump ตาราง `app_comments`
--

INSERT INTO `app_comments` (`id`, `entities_id`, `items_id`, `created_by`, `description`, `attachments`, `date_added`) VALUES
(3, 22, 4, 21, 'edit', '', 1471864820),
(4, 22, 3, 21, 'dfgdfgdfg', '', 1471864919),
(5, 22, 4, 21, '', '', 1471865354),
(6, 22, 4, 20, 'aaa', '', 1471866087),
(7, 22, 7, 22, 'ต้องรอรันคิวรีกลางคืน กลัวมีผลกับการใช้แอพ', '', 1471946900),
(8, 22, 18, 22, '', '', 1472716968),
(9, 22, 8, 22, 'ทำมา2สัปดาห์แล้ว ยังไม่เสร็จสักที', '', 1474251562),
(10, 22, 8, 22, 'ทำเสร็จ ยังจะ บัค', '', 1474251609),
(11, 22, 25, 22, 'ติดตรง ฟิลด์ zipcode not null', '', 1474258993),
(12, 22, 27, 22, '', '1474259775_send-mail.png', 1474259787),
(13, 22, 12, 22, '', '', 1474260836),
(14, 22, 13, 22, '', '', 1474261326),
(15, 22, 10, 22, 'ตรวจสอบความถูกต้อง', '', 1474261370),
(16, 22, 26, 22, '1 : No permission\r\n2 : Not found document\r\n3 : No assigner', '', 1474262834),
(17, 22, 15, 22, 'test อีกครั้ง\r\n', '', 1474262876),
(18, 22, 24, 22, '', '', 1474280374),
(19, 22, 16, 22, 'เปลี่ยนเป็นแบบล็อคปุ่มเอาแล้วกันเวลาขยายจะได้ไม่เลื่อนลงไปข้างล่าง', '1474280890_type_case_1.png', 1474280892),
(20, 22, 27, 22, 'success', '', 1474280957),
(21, 22, 15, 22, 'ไม่รู้จะใช้กระดาษขนาดใด ตอนนี้ default เป็น A4 ', '', 1474339998),
(22, 22, 28, 22, '', '', 1474345273),
(23, 22, 17, 22, 'เสร็จแล้ว แต่ยังไม่ได้ส่งให้ AE', '1474345734_ADTechnicalManual.docx', 1474345761),
(24, 22, 18, 22, 'เสร็จแล้ว ใน เครื่อง DEV ต้องไปอัพที่ สรรพสามิต', '', 1474345841),
(25, 22, 29, 20, 'file\r\nlib\\languages\\define_lang_en.php\r\nlib\\languages\\define_lang_th.php\r\nlib\\languages\\define_lang_zh.php\r\nprograms\\whereteam\\index\\add_customer.php\r\nprograms\\whereteam\\index\\add_customer_action.php\r\nprograms\\whereteam\\index\\wtt_customer_action.php\r\nprograms\\whereteam\\index\\wtt_customer_view_detail.php\r\nprograms\\whereteam\\index_function.js\r\ntemplates\\ais\\index.php\r\n\r\nDB\r\nเพิ่มฟิวใน table wt_member_limit\r\n- limit_onair (int 11),\r\n- limit_monitor (int 11),\r\n- limit_dispatcher (int 11),\r\n', '', 1474439768),
(26, 22, 30, 22, 'รอขึ้น server', '1474451618_fineusermobile.png', 1474451633),
(27, 22, 41, 22, 'รออัพ', '1474451714_fineusermobile.png', 1474451715),
(28, 22, 30, 22, 'อันเมื่อกี้ผิด \r\nรออัพ', '1474452198_findusermobile.png', 1474452199),
(29, 22, 35, 22, 'ทำงานตรงกันแล้ว', '', 1474631552),
(30, 22, 56, 20, 'ทำใส่ใน ais และ admin whereteam แล้ว', '', 1475049341),
(31, 22, 56, 20, 'file งาน\r\n- programs\\whereteam\\index.php\r\n- programs\\whereteam\\wt_js.js\r\n- programs\\whereteam\\index\\wtt_room_list.php\r\n- programs\\whereteam\\index\\wtt_map_trackerlimit.php', '', 1475049494);

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `app_comments_access`
--

DROP TABLE IF EXISTS `app_comments_access`;
CREATE TABLE IF NOT EXISTS `app_comments_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `access_groups_id` int(11) NOT NULL,
  `access_schema` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_access_groups_id` (`access_groups_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- dump ตาราง `app_comments_access`
--

INSERT INTO `app_comments_access` (`id`, `entities_id`, `access_groups_id`, `access_schema`) VALUES
(4, 21, 6, 'view,create'),
(5, 21, 5, 'view,create'),
(6, 21, 4, 'view,create,update,delete'),
(7, 22, 5, 'view,create'),
(8, 22, 4, 'view,create,update,delete'),
(9, 23, 6, 'view,create'),
(10, 23, 4, 'view,create,update,delete'),
(11, 24, 5, 'view,create'),
(12, 24, 4, 'view,create,update,delete');

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `app_comments_history`
--

DROP TABLE IF EXISTS `app_comments_history`;
CREATE TABLE IF NOT EXISTS `app_comments_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comments_id` int(11) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `fields_value` text,
  PRIMARY KEY (`id`),
  KEY `idx_comments_id` (`comments_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=42 ;

--
-- dump ตาราง `app_comments_history`
--

INSERT INTO `app_comments_history` (`id`, `comments_id`, `fields_id`, `fields_value`) VALUES
(4, 3, 169, '49'),
(5, 3, 170, '55'),
(6, 3, 174, '0'),
(7, 4, 169, '48'),
(8, 4, 170, '53'),
(9, 5, 169, '49'),
(10, 5, 170, '53'),
(11, 6, 169, '47'),
(12, 6, 170, '55'),
(13, 7, 169, '48'),
(14, 8, 169, '48'),
(15, 8, 170, '54'),
(16, 9, 169, '48'),
(17, 9, 170, '53'),
(18, 10, 169, '48'),
(19, 10, 170, '53'),
(20, 11, 169, '49'),
(21, 12, 169, '48'),
(22, 12, 170, '53'),
(23, 13, 169, '49'),
(24, 13, 174, '1'),
(25, 14, 169, '49'),
(26, 15, 169, '48'),
(27, 16, 169, '49'),
(28, 17, 169, '48'),
(29, 18, 169, '49'),
(30, 19, 169, '49'),
(31, 19, 170, '55'),
(32, 20, 169, '49'),
(33, 20, 170, '53'),
(34, 21, 169, '49'),
(35, 22, 169, '49'),
(36, 23, 169, '48'),
(37, 25, 169, '49'),
(38, 26, 169, '48'),
(39, 27, 169, '48'),
(40, 28, 169, '48'),
(41, 29, 169, '49');

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `app_configuration`
--

DROP TABLE IF EXISTS `app_configuration`;
CREATE TABLE IF NOT EXISTS `app_configuration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `configuration_name` varchar(255) NOT NULL DEFAULT '',
  `configuration_value` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=53 ;

--
-- dump ตาราง `app_configuration`
--

INSERT INTO `app_configuration` (`id`, `configuration_name`, `configuration_value`) VALUES
(9, 'CFG_APP_NAME', 'PHPTracker'),
(10, 'CFG_APP_SHORT_NAME', 'Tracker'),
(11, 'CFG_APP_LOGO', ''),
(12, 'CFG_EMAIL_USE_NOTIFICATION', '0'),
(13, 'CFG_EMAIL_SUBJECT_LABEL', ''),
(14, 'CFG_EMAIL_AMOUNT_PREVIOUS_COMMENTS', '2'),
(15, 'CFG_EMAIL_COPY_SENDER', '0'),
(16, 'CFG_EMAIL_SEND_FROM_SINGLE', '0'),
(17, 'CFG_EMAIL_ADDRESS_FROM', ''),
(18, 'CFG_EMAIL_NAME_FROM', ''),
(19, 'CFG_EMAIL_USE_SMTP', '0'),
(20, 'CFG_EMAIL_SMTP_SERVER', ''),
(21, 'CFG_EMAIL_SMTP_PORT', ''),
(22, 'CFG_EMAIL_SMTP_ENCRYPTION', ''),
(23, 'CFG_EMAIL_SMTP_LOGIN', ''),
(24, 'CFG_EMAIL_SMTP_PASSWORD', ''),
(25, 'CFG_LDAP_USE', '0'),
(26, 'CFG_LDAP_SERVER_NAME', NULL),
(27, 'CFG_LDAP_SERVER_PORT', NULL),
(28, 'CFG_LDAP_BASE_DN', NULL),
(29, 'CFG_LDAP_UID', NULL),
(30, 'CFG_LDAP_USER', NULL),
(31, 'CFG_LDAP_EMAIL_ATTRIBUTE', NULL),
(32, 'CFG_LDAP_USER_DN', NULL),
(33, 'CFG_LDAP_PASSWORD', NULL),
(34, 'CFG_LOGIN_PAGE_HEADING', ''),
(35, 'CFG_LOGIN_PAGE_CONTENT', ''),
(36, 'CFG_APP_TIMEZONE', 'Asia/Bangkok'),
(37, 'CFG_APP_DATE_FORMAT', 'm/d/Y'),
(38, 'CFG_APP_DATETIME_FORMAT', 'm/d/Y H:i'),
(39, 'CFG_APP_ROWS_PER_PAGE', '10'),
(40, 'CFG_REGISTRATION_EMAIL_SUBJECT', NULL),
(41, 'CFG_REGISTRATION_EMAIL_BODY', NULL),
(42, 'CFG_PASSWORD_MIN_LENGTH', '5'),
(43, 'CFG_APP_LANGUAGE', 'english.php'),
(44, 'CFG_APP_SKIN', ''),
(45, 'CFG_PUBLIC_USER_PROFILE_FIELDS', ''),
(46, 'CFG_APP_LOGO_URL', ''),
(47, 'CFG_APP_COPYRIGHT_NAME', ''),
(48, 'CFG_APP_NUMBER_FORMAT', '2/./*'),
(49, 'CFG_APP_FIRST_DAY_OF_WEEK', '0'),
(50, 'CFG_APP_DISPLAY_USER_NAME_ORDER', 'firstname_lastname'),
(51, 'CFG_ALLOW_CHANGE_USERNAME', '0'),
(52, 'CFG_ALLOW_REGISTRATION_WITH_THE_SAME_EMAIL', '0');

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `app_entities`
--

DROP TABLE IF EXISTS `app_entities`;
CREATE TABLE IF NOT EXISTS `app_entities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `display_in_menu` tinyint(1) DEFAULT '0',
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=25 ;

--
-- dump ตาราง `app_entities`
--

INSERT INTO `app_entities` (`id`, `parent_id`, `name`, `display_in_menu`, `sort_order`) VALUES
(1, 0, 'Users', 0, 10),
(21, 0, 'Projects', 0, 1),
(22, 21, 'Tasks', 0, 1),
(23, 21, 'Tickets', 0, 2),
(24, 21, 'Discussions', 0, 3);

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `app_entities_access`
--

DROP TABLE IF EXISTS `app_entities_access`;
CREATE TABLE IF NOT EXISTS `app_entities_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `access_groups_id` int(11) NOT NULL,
  `access_schema` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_access_groups_id` (`access_groups_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=40 ;

--
-- dump ตาราง `app_entities_access`
--

INSERT INTO `app_entities_access` (`id`, `entities_id`, `access_groups_id`, `access_schema`) VALUES
(28, 21, 6, 'view_assigned'),
(29, 21, 5, 'view_assigned,reports'),
(30, 21, 4, 'view,create,update,delete,reports'),
(31, 22, 6, ''),
(32, 22, 5, 'view,create,update,reports'),
(33, 22, 4, 'view,create,update,delete,reports'),
(34, 23, 6, 'view_assigned,create,update,reports'),
(35, 23, 5, ''),
(36, 23, 4, 'view,create,update,delete,reports'),
(37, 24, 6, ''),
(38, 24, 5, 'view_assigned,create,update,delete,reports'),
(39, 24, 4, 'view,create,update,delete,reports');

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `app_entities_configuration`
--

DROP TABLE IF EXISTS `app_entities_configuration`;
CREATE TABLE IF NOT EXISTS `app_entities_configuration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `configuration_name` varchar(255) NOT NULL DEFAULT '',
  `configuration_value` text,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=57 ;

--
-- dump ตาราง `app_entities_configuration`
--

INSERT INTO `app_entities_configuration` (`id`, `entities_id`, `configuration_name`, `configuration_value`) VALUES
(11, 1, 'menu_title', 'Users'),
(12, 1, 'listing_heading', 'Users'),
(13, 1, 'window_heading', 'User Info'),
(14, 1, 'insert_button', 'Add User'),
(15, 1, 'use_comments', '0'),
(25, 21, 'menu_title', ' Projects'),
(26, 21, 'listing_heading', ' Projects'),
(27, 21, 'window_heading', 'Project Info'),
(28, 21, 'insert_button', 'Add Project'),
(29, 21, 'email_subject_new_item', 'New Project:'),
(30, 21, 'use_comments', '1'),
(31, 21, 'email_subject_new_comment', 'New project comment:'),
(32, 22, 'menu_title', 'Tasks'),
(33, 22, 'listing_heading', 'Tasks'),
(34, 22, 'window_heading', 'Task Info'),
(35, 22, 'insert_button', 'Add Task'),
(36, 22, 'email_subject_new_item', 'New Task'),
(37, 22, 'use_comments', '1'),
(38, 22, 'email_subject_new_comment', 'New task comment:'),
(39, 23, 'menu_title', 'Tickets'),
(40, 23, 'listing_heading', 'Tickets'),
(41, 23, 'window_heading', 'Ticket Info'),
(42, 23, 'insert_button', 'Add Ticket'),
(43, 23, 'email_subject_new_item', 'New Ticket:'),
(44, 23, 'use_comments', '1'),
(45, 23, 'email_subject_new_comment', 'New ticket comment'),
(46, 24, 'menu_title', 'Discussions'),
(47, 24, 'listing_heading', 'Discussions'),
(48, 24, 'window_heading', 'Discussion Info'),
(49, 24, 'insert_button', 'Add Discussion'),
(50, 24, 'email_subject_new_item', 'New Discussion:'),
(51, 24, 'use_comments', '1'),
(52, 24, 'email_subject_new_comment', 'New discussion comment:'),
(53, 21, 'use_editor_in_comments', '0'),
(54, 22, 'use_editor_in_comments', '0'),
(55, 23, 'use_editor_in_comments', '0'),
(56, 24, 'use_editor_in_comments', '0');

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `app_entity_1`
--

DROP TABLE IF EXISTS `app_entity_1`;
CREATE TABLE IF NOT EXISTS `app_entity_1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `parent_item_id` int(11) NOT NULL DEFAULT '0',
  `linked_id` int(11) NOT NULL DEFAULT '0',
  `date_added` int(11) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `password` varchar(255) NOT NULL,
  `field_5` text,
  `field_6` text,
  `field_7` text,
  `field_8` text,
  `field_9` text,
  `field_10` text,
  `field_12` text,
  `field_13` text,
  `field_14` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 ;

--
-- dump ตาราง `app_entity_1`
--

INSERT INTO `app_entity_1` (`id`, `parent_id`, `parent_item_id`, `linked_id`, `date_added`, `created_by`, `sort_order`, `password`, `field_5`, `field_6`, `field_7`, `field_8`, `field_9`, `field_10`, `field_12`, `field_13`, `field_14`) VALUES
(19, 0, 0, 0, 0, NULL, 0, '$P$ExcrQqmrVbZ600FKV8Eu0FF825kd0o0', '1', '0', 'PHP', 'Developer', 'devphp2016@gmail.com', '', 'SYS', 'english.php', 'blue'),
(20, 0, 0, 0, 1471860937, 19, 0, '$P$EalQ2lZytlolyt8ZKZvpkKuxXaOBy..', '1', '5', 'Tong', 'SONE', 'chatchai@mozermobile.com', '1472021518_large.png', 'nj_tong', 'english.php', 'default'),
(21, 0, 0, 0, 1471864004, 19, 0, '$P$E.0kf2BJHYCXdcAVzORO7OSjekf.c6/', '1', '5', 'aon', 'aonaon', 'aon@mail.com', '', 'aon', 'english.php', 'blue'),
(22, 0, 0, 0, 1471914220, 19, 0, '$P$EqnC0GhOkBG.Ndh6tZLibFTisNsLBQ0', '1', '5', 'Natcha', 'pui', 'mailfortasks@gmail.com', '1471938305_8iA6AjjaT.jpg', 'pui', 'english.php', 'blue'),
(23, 0, 0, 0, 1471914368, 19, 0, '$P$EdqWg5bNGJD.PCwn1qq95RJwpcTcgH0', '1', '5', 'tong', 'tong', 'tong@test', '', 'tong', 'english.php', 'blue'),
(24, 0, 0, 0, 1471914408, 19, 0, '$P$E6DqiFjhsNWNmcOF0O3FMLvWs3J.Fy0', '1', '5', 'front', 'front', 'front@test', '', 'front', 'english.php', 'blue'),
(25, 0, 0, 0, 1471914456, 19, 0, '$P$EVBwAG3TE/bygOX5nf5IIQTSKc0S1/0', '1', '5', 'top', 'top', 'top@test', '', 'top', 'english.php', 'blue'),
(26, 0, 0, 0, 1471914553, 19, 0, '$P$E3q9WuPutBeRX4IWCFzmahgtXwoWTT.', '1', '5', 'song', 'song', 'song@test', '1471931698_large.png', 'song', 'english.php', 'default');

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `app_entity_21`
--

DROP TABLE IF EXISTS `app_entity_21`;
CREATE TABLE IF NOT EXISTS `app_entity_21` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT '0',
  `parent_item_id` int(11) DEFAULT '0',
  `linked_id` int(11) DEFAULT '0',
  `date_added` int(11) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `sort_order` int(11) DEFAULT '0',
  `field_156` text NOT NULL,
  `field_157` text NOT NULL,
  `field_158` text NOT NULL,
  `field_159` text NOT NULL,
  `field_160` text NOT NULL,
  `field_161` text NOT NULL,
  `field_162` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- dump ตาราง `app_entity_21`
--

INSERT INTO `app_entity_21` (`id`, `parent_id`, `parent_item_id`, `linked_id`, `date_added`, `created_by`, `sort_order`, `field_156`, `field_157`, `field_158`, `field_159`, `field_160`, `field_161`, `field_162`) VALUES
(1, 0, 0, 0, 1471861754, 19, 0, '34', '38', 'ระบบสอบสวน TCSD', '1471885200', '', '21,24,22,20,26,23,25', ''),
(2, 0, 0, 0, 1471862157, 19, 0, '34', '38', 'DTI Talk', '1471798800', '', '21,24,22,20,26,23,25', ''),
(3, 0, 0, 0, 1471864078, 19, 0, '34', '37', 'TU', '', '', '21,26,23', ''),
(4, 0, 0, 0, 1471917620, 19, 0, '34', '37', 'iPolice', '1471885200', '', '21,24,22,20,26,23,25', ''),
(5, 0, 0, 0, 1471939461, 19, 0, '34', '37', 'ECT Talk', '1471885200', 'Sub set of https://admin.whereteam.com', '22,20,19', ''),
(6, 0, 0, 0, 1472183366, 19, 0, '34', '37', 'Admin.whereteam', '1472144400', 'ประกอบด้วย การแก้ไข bug และการเพิ่ม feature ต่างๆ', '21,22,20,23,19', ''),
(7, 0, 0, 0, 1472716183, 19, 0, '34', '37', 'ED Talk', '1472662800', 'Mozer Talk&nbsp;<br />\r\nกรมสรรพสามิต', '22,20,19', ''),
(8, 0, 0, 0, 1474428635, 19, 0, '34', '37', ' AIS Whereteam', '1474390800', '', '22,20', ''),
(9, 0, 0, 0, 1475208315, 19, 0, '34', '37', 'Mozer Taxi', '1475427600', '', '22,20', '');

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `app_entity_22`
--

DROP TABLE IF EXISTS `app_entity_22`;
CREATE TABLE IF NOT EXISTS `app_entity_22` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT '0',
  `parent_item_id` int(11) DEFAULT '0',
  `linked_id` int(11) DEFAULT '0',
  `date_added` int(11) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `sort_order` int(11) DEFAULT '0',
  `field_167` text NOT NULL,
  `field_168` text NOT NULL,
  `field_169` text NOT NULL,
  `field_170` text NOT NULL,
  `field_171` text NOT NULL,
  `field_172` text NOT NULL,
  `field_173` text NOT NULL,
  `field_174` text NOT NULL,
  `field_175` text NOT NULL,
  `field_176` text NOT NULL,
  `field_177` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=59 ;

--
-- dump ตาราง `app_entity_22`
--

INSERT INTO `app_entity_22` (`id`, `parent_id`, `parent_item_id`, `linked_id`, `date_added`, `created_by`, `sort_order`, `field_167`, `field_168`, `field_169`, `field_170`, `field_171`, `field_172`, `field_173`, `field_174`, `field_175`, `field_176`, `field_177`) VALUES
(1, 0, 1, 0, 1471862923, 20, 0, '44', 'ปฏิทิน show ค้าง', '49', '55', '20', 'login user: tcsd4 pass:123456<br />\r\nกด สมุดคุมคดีสอบสวน และปุ่มค้นหาละเอียด', '', '', '', '', '1471862919_2016-08-22_175724.jpg'),
(2, 0, 1, 0, 1471863415, 20, 0, '44', 'กดปุ่มเพิ่มคดีแล้วค้าง', '49', '55', '20', 'login user: tcsd4 pass:123456<br />\r\nกด สมุดคุมคดีสอบสวน และกดปุ่มเพิ่มคดีแล้วค้างหลังจาก กดค้นหาแบบรายละเอียด', '', '', '', '', ''),
(3, 0, 3, 0, 1471864264, 21, 0, '44', 'ทดสอบ bag', '48', '53', '21', 'asdasd', '', '', '', '', ''),
(4, 0, 3, 0, 1471864574, 21, 0, '42', 'sssss', '47', '55', '20', 'งาน tu ผม<br />\r\n1.แก้ไขจัดการงวดให้ดึง ชื่องวดมาแสดง 5 หมวด<br />\r\n2.ทดสอบการแจ่งเตือน งวดงานงวดเงิน<br />\r\n3.ทำแนบเอกสารสัญญา<br />\r\n4.แก้ไขรายงาน วัสดุ แสดง รูปแบบเงินไม่ถูก', '', '0', '', '', ''),
(5, 0, 4, 0, 1471917758, 24, 0, '42', 'งาน test', '52', '55', '25', '', '', '', '', '', ''),
(6, 0, 4, 0, 1471924060, 20, 0, '45', 'Note', '46', '55', '24,20,25', 'http://www.police4.go.th/ipolice/<br />\r\nuser:&nbsp;police4<br />\r\npass: 4444', '', '', '', '', '1471924958_สมุดงาน1.pdf'),
(7, 0, 5, 0, 1471939841, 22, 0, '42', 'กำหนดสิทธิ์ broadcast ในห้องรวมประเทศให้ ยูส สนง.กกต.จว. ทุกจังหวัด', '50', '53', '22', 'จากเดิม ห้องรวมประเทศ จะสามารถมีสิทธิ์ใช้ braodcast ได้ไม่กี่ยูส มี request ให้เปิดสิทธิ์เพิ่มให้กับ สมาชิกที่อยู่ห้อง สนง.กกต.จว. ทุกจังหวัด', '4', '', '1471885200', '1471885200', ''),
(8, 0, 1, 0, 1472017941, 22, 0, '42', 'ระบบรับแจ้ง ปรับ UI หน้ารับแจ้ง และเพิ่มการใส่รูปผู้ต้องสงสัย/ผู้ต้องหา', '49', '53', '22', '- ที่ทำไว้ตอนแรก ไม่มีใส่รูปผู้ต้องหา/ผู้ต้องสงสัย<br />\r\n<br />\r\n- ปรับหน้าฟอร์มให้เหมือน https://eoffice1.com/ect/?program=101 (SYS/123456)<br />\r\n<br />\r\n&nbsp;', '', '', '1471798800', '1473181200', '1472178672_newform01.png'),
(9, 0, 1, 0, 1472178965, 20, 0, '42', 'ทำ Barcode หนังสือเวียน', '49', '55', '20', '', '', '', '', '', ''),
(10, 0, 1, 0, 1472179667, 22, 0, '43', 'ระบบรับแจ้ง ปรับ UI หน้าพนักงานสอบสวน', '48', '55', '22', 'ต้องมี&nbsp;<br />\r\n- field การดำเนินการ (แจ้งเป็นหลักฐาน, ตรวจสอบข้อเท็จจริง, รับคดีสอบสวน)<br />\r\n- ทำtabข้อมูลผู้แจ้งไว้ต่างหาก เผื่อดูเพื่อไม่ให้รกdialog<br />\r\n&nbsp;', '', '', '', '', '1472179665_addcasetranstoreceivetype01.png'),
(11, 0, 1, 0, 1472179996, 22, 0, '42', 'ระบบรับแจ้ง เพิ่มปุ่ม entity link', '46', '55', '22', 'ใส่ปุ่ม ใน list และสามารถวิเคราะห์ได้จากฐานข้อมูลเวปอื่นว่า เป็นผู้ต้องหาจากฐานข้อมูลอื่นหรือไม่ โดยเทียบจาก id 13 หลักที่มีการบันทึกเข้ามา<br />\r\nhttp://www.criminaldatacenter.com/cdc/<br />\r\n&nbsp;', '', '', '', '', ''),
(12, 0, 1, 0, 1472180717, 22, 0, '42', 'ระบบรับแจ้ง เพิ่มฟิลด์ passport ในเก็บข้อมูลผู้แจ้ง', '49', '55', '22', 'ทำเป็น radio&nbsp;<br />\r\n- บัตรประชาชน (default)<br />\r\n- passport ID (maxlength 100)', '', '1', '', '', ''),
(13, 0, 1, 0, 1472180877, 22, 0, '42', 'ระบบรับแจ้ง เพิ่มฟิลด์ พฤติการณ์แห่งคดี', '49', '55', '22', 'เพิ่มฟิลด์ไว้ตรงหลังที่เกิดเหตุ ในฟอร์มสำหรับพนักงานสอบสวน ขนาดเท่ากับสถานที่เกิดเหตุ', '', '', '', '', ''),
(14, 0, 1, 0, 1472182319, 22, 0, '42', 'ระบบรับแจ้ง เมื่อพนักงานสอบดำเนินการแล้ว ให้เพิ่มใน เคส สอบสวนด้วย', '48', '55', '22', 'ยังไม่รู้จะต้องทำอย่างไร&nbsp;', '', '', '', '', ''),
(15, 0, 1, 0, 1472182404, 22, 0, '42', 'ระบบรับแจ้ง พิมพ์ออกมาใน กระดาษขนาด A5', '49', '55', '', 'ให้สามารถพิมพ์ออกมาได้ หลังจากพนักงานสอบสวนดำเนินการแล้ว เพื่อเป็นหลักฐานในการรับแจ้ง', '', '', '', '', ''),
(16, 0, 1, 0, 1472182487, 22, 0, '42', 'ระบบรับแจ้ง แสดง list ของ dialog ประเภทรับแจ้งเหตุ ', '49', '55', '22', 'ใน ส่วนการทำงานของพนักงานสอบสวน<br />\r\nอาจแบ่งเป็น 2-3 คอลัมน์', '', '', '', '', '1472182485_receivetype.png'),
(17, 0, 2, 0, 1472182885, 22, 0, '42', 'ทำคู่มือทางเทคนิค', '48', '55', '22', 'DTI Sync AD Member', '', '', '', '', ''),
(18, 0, 7, 0, 1472716247, 19, 0, '42', 'Dispatcher เพิ่มส่วนที่บอกว่า ใครเป็นผู้อ่านข้อความในห้องสนทนาบ้าง', '49', '54', '22', 'เพิ่มเพื่อให้ตรงกับ TOR ที่ได้ทำการส่งกับ บ.จันวานิช', '', '', '1472576400', '1472662800', ''),
(19, 0, 1, 0, 1473157258, 20, 0, '42', 'หน้าเอกสารสร้าง', '49', '53', '20', '- ให้ทำ Barcode เอาเลข&nbsp;ID :&nbsp;6 &nbsp;หรือ ID + program id<br />\r\n- ทำ ปุ่มให้ชัดว่าเลือก เมนูไหนอยู่<br />\r\n- ตรงเลขที่ เปลี่ยนเป็น เลขที่เอกสาร', '', '', '', '', '1473157437_2016-09-06_172359.jpg'),
(20, 0, 1, 0, 1473157991, 20, 0, '42', 'หน้าส่งเอกสาร', '49', '53', '20', '- เอา colum find ID มาใส่<br />\r\n- ตรงเลขที่ เปลี่ยนเป็น เลขที่เอกสาร<br />\r\n- คอลัม สถานะ เปลี่ยนเป็น&nbsp;<br />\r\n&nbsp; &nbsp; &nbsp; &nbsp;จำนวนผู้รับทั้งหมด : 9<br />\r\n&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;ลงรับเอกสาร : 0<br />\r\n&nbsp; &nbsp; &nbsp; &nbsp;อนุมัติ : 1<br />\r\n&nbsp; &nbsp; &nbsp; &nbsp;ไม่อนุมัติ : 8<br />\r\n&nbsp;- config อนุมัติ และไม่อนุมัติ &nbsp; &nbsp; &nbsp;', '', '', '1473094800', '1473267600', '1473157574_2016-09-06_174156.jpg'),
(21, 0, 1, 0, 1473159034, 20, 0, '42', 'หน้าเอกสารเข้า', '49', '53', '20', '- เอา คอลัม ID มาใส่ จากหน้าสร้างเอกสาร<br />\r\n- ปุ่ม&nbsp;อนุมัติเอกสาร ให้ ทำ check box อนุมัติ และไม่อนุมัตื<br />\r\n- ปุ่ม&nbsp;แก้ไขอนุมัติเอกสาร เปลี่นเป็นแก้ไข<br />\r\n- ปุ่ม&nbsp;แก้ไขอนุมัติ เปลี่นเป็นแก้ไข ใน view<br />\r\n- dialog แก้ไข ปรับให้เล็กลงหน่อย', '', '', '', '', ''),
(22, 0, 1, 0, 1473159133, 20, 0, '42', 'เพิ่มปุ่มและหน้า dialog สำหรับลงรับหนังสือ', '49', '53', '20', 'เพิ่มปุ่มและหน้า dialog สำหรับรับหนังสือ (ชื่อปุ่มว่า ลงรับเอกสารด้วย Barcode)<br />\r\n**ให้ยิงครั้งเดียวลงรับ', '', '', '', '', ''),
(23, 0, 1, 0, 1473159187, 20, 0, '42', 'ประเภทเอกสารให้เพิ่มได้ทุกคน', '49', '53', '20', 'ประเภทเอกสาร เพิ่มได้ทุกคน<br />\r\n**เช็คซ้ำด้วย', '', '', '', '', ''),
(24, 0, 1, 0, 1473388270, 22, 0, '44', 'ปรับ UI รูปตอน upload', '49', '55', '22', '', '', '', '', '', '1473388267_image_err1.png'),
(25, 0, 1, 0, 1474258723, 22, 0, '44', 'ตอนรับแจ้ง บันทึกไม่ได้', '49', '53', '22', '', '', '', '', '', ''),
(26, 0, 1, 0, 1474258788, 22, 0, '44', 'ตอนอ่านบาร์โค้ด หากอ่าน id ที่ไม่มีข้อมูลไม่สามารถดักไว้ได้', '49', '53', '22', '', '1', '', '1474218000', '1474218000', ''),
(27, 0, 1, 0, 1474259708, 22, 0, '42', 'เช็คการส่งเมล์ให้ผู้แจ้งหลังจากพนักงานสอบสวนรับเรื่องแล้ว', '49', '53', '22', '', '', '', '', '', ''),
(28, 0, 1, 0, 1474345169, 22, 0, '44', 'pagination error', '49', '55', '', '', '', '', '', '', ''),
(29, 0, 8, 0, 1474428859, 20, 0, '42', 'ทำ setting ให้กำหนดจำนวน user onair, monitor, dispatcher', '49', '55', '20', 'ทำ setting ให้กำหนดจำนวน user onair, monitor, dispatcher ได้ โดยให้ SYSเป็นผู้ดำเนินการ<br />\r\n<br />\r\n*** มีใน dev ยังไม่ได้เอาขึ้นตัวจริง (re-check ก่อน)', '', '', '', '', ''),
(30, 0, 8, 0, 1474428899, 20, 0, '42', 'ให้ SYS และ admin สามารถค้นหา user mobile จากทุก program id', '49', '55', '22', 'ให้ SYS และ admin สามารถค้นหา user mobile จากทุก program id ได้ การแสดงผลให้แสดง user / program id<br />\r\n<br />\r\n&nbsp;', '', '', '', '', ''),
(31, 0, 8, 0, 1474428943, 20, 0, '42', 'ปรับการแสดงผลในเมนู ภาพทั้งหมด', '49', '55', '22', '', '', '', '', '', ''),
(32, 0, 8, 0, 1474428972, 20, 0, '42', 'เมนูู Capture detection ปรับขนาดรูปภาพที่แสดงในลิสรายการ', '49', '55', '22', 'เมนูู Capture detection ปรับขนาดรูปภาพที่แสดงในลิสรายการ ให้เล็กลงเพื่อให้สามารถแสดงรายการในแต่ละหน้าได้มากขึ้น', '', '', '1474477200', '1474477200', ''),
(33, 0, 8, 0, 1474429082, 20, 0, '42', 'การสร้าง user mobile ใหม่ให้กำหนดให้ใช้ location ได้เลย', '49', '55', '20', 'การสร้าง user mobile ใหม่ให้กำหนดให้ใช้ location ได้เลย<br />\r\n<br />\r\nเช็ค&nbsp;<br />\r\nwt_member.locationSuser= 1', '', '', '', '', ''),
(34, 0, 8, 0, 1474429108, 20, 0, '42', 'ปุ่มแก้ไข save ใน Dialog ต่างๆ เปลี่ยนให้เป็นบันทึกทั้งหมด', '49', '55', '20', 'ปุ่มแก้ไข save ใน Dialog ต่างๆ เปลี่ยนให้เป็นบันทึกทั้งหมด', '', '', '', '', ''),
(35, 0, 8, 0, 1474429124, 20, 0, '42', 'เช็คการทำงานของการค้นหาในเมนูขวา ให้ตรงกับการค้นหาในหน้า home', '49', '55', '', 'เช็คการทำงานของการค้นหาในเมนูขวา ให้ตรงกับการค้นหาในหน้า home', '', '', '', '', ''),
(36, 0, 8, 0, 1474429147, 20, 0, '42', 'ปรับการทำงานของเมนู กราฟรายงานสถิติการใช้งาน', '49', '55', '22,20', 'ปรับการทำงานของเมนู กราฟรายงานสถิติการใช้งาน (admin.whereteam สามารถเรียกดูเป็นวันได้)', '', '', '', '', ''),
(37, 0, 8, 0, 1474429191, 20, 0, '42', 'ปรับเมนู กราฟรายงานสถิติการใช้งานที่มีอยู่ 6 กราฟ', '49', '55', '20', 'ปรับเมนู กราฟรายงานสถิติการใช้งาน โดยสร้าง list ของกราฟที่มีอยู่ 6 กราฟ เมื่อคลิกแล้วให้แสดงแต่ละกราฟ (คนละ dialog)', '', '', '', '', ''),
(38, 0, 8, 0, 1474429221, 20, 0, '42', 'เก็บ Log ในขั้นตอนสำคัญต่างๆ ', '46', '55', '', 'เก็บ Log ในขั้นตอนสำคัญต่างๆ', '', '', '', '', ''),
(39, 0, 8, 0, 1474429236, 20, 0, '42', 'ทำให้ monitor, onair, dispatcher เปลี่ยน Logo ได้จาก admin', '49', '55', '22', 'ทำให้ monitor, onair, dispatcher เปลี่ยน Logo ได้จาก admin', '', '', '1474477200', '1474563600', ''),
(40, 0, 8, 0, 1474429286, 20, 0, '42', 'ให้มี confirm เมื่อทำการเพิ่ม user monitor', '49', '55', '22', 'เมื่อทำการเพิ่ม user monitor แล้วให้มี confirm ถามว่าจะเพิ่ม user monitor อีกหรือไม่ ถ้าตอบไม่ให้ปิด dialog', '', '', '1474477200', '1474477200', ''),
(41, 0, 6, 0, 1474451460, 22, 0, '42', 'ให้ SYS และ admin สามารถค้นหา user mobile จากทุก program id', '49', '55', '22', 'ให้ SYS และ admin สามารถค้นหา user mobile จากทุก program id ได้ การแสดงผลให้แสดง user / program id', '', '', '', '', ''),
(42, 0, 8, 0, 1474458423, 22, 0, '42', 'ใส่การแก้ไขจำนวน user monitor, onair, dispatcher ใน lifeprogram', '49', '55', '22', '', '', '', '', '', ''),
(43, 0, 6, 0, 1474622497, 22, 0, '42', 'ปรับ service type ให้เป็นตามเวป mozermobile.com', '46', '55', '22', '', '', '', '', '', '1474622486_enterprise_options.png,1474622488_standard_options.png'),
(44, 0, 6, 0, 1474622593, 22, 0, '42', 'เพิ่ม service type ให้เป็น enterprise', '52', '55', '22', '', '', '', '', '', '1474622515_enterprise_options.png,1474622517_standard_options.png'),
(45, 0, 6, 0, 1474622947, 22, 0, '42', 'เพิ่ม feature ที่กำหนดห้องขั้นต่ำ', '46', '55', '22,20', 'จำนวนคน หารด้วย 2<br />\r\nแต่ห้ามเกิน 500 ห้อง<br />\r\nหาก ลค ต้องการมากกว่านี้ ให้ SYS เป็นผู้จัดการได้', '', '', '', '', ''),
(46, 0, 8, 0, 1474624756, 20, 0, '42', 'หน้ากราฟสถิติการใช้งาน 6 กราฟ query ยังช้า', '49', '55', '20', 'query ที่ช้า คือ กราฟ<br />\r\n-&nbsp;ผู้ที่อ่านข้อความมากที่สุด<br />\r\n<br />\r\nและดู report รายวันว่าใช้ได้เปล่า', '', '', '', '', ''),
(47, 0, 6, 0, 1474624929, 22, 0, '42', 'ตรวจสอบและปรับปรุง Expire user ให้สมบูรณ์', '46', '55', '22,20', '- หากหมดอายุเกิน 30 วัน ให้ระงับการใช้งาน (kick user mobile) (run cron)<br />\r\n- หากทำการต่ออายุ ให้นับจากวันที่หมดอายุ ไม่ใช่นับจากวันที่ต่ออายุ ???<br />\r\n&nbsp;', '', '', '', '', ''),
(48, 0, 6, 0, 1474625488, 22, 0, '42', 'จัดทำคู่มือการใช้งาน admin.whereteam', '46', '55', '22', '- ตัวรับแจ้งปัญหา<br />\r\n- การใช้งาน expire date<br />\r\n- การเปิดลูกค้าใหม่', '', '', '', '', ''),
(49, 0, 6, 0, 1474625615, 22, 0, '42', 'เพิ่มการแก้ไข default dispatcher, onair, monitor ในส่วนของ life program', '46', '55', '22', '', '', '', '', '', '1474625612_default_user_lifeprogram.png'),
(50, 0, 8, 0, 1474626200, 22, 0, '42', 'ปรับ UI Title Header', '46', '55', '', 'ให้ คำว่า Dispatcher ใหญ่กว่านี้ และให้อยู่ตรงกลาง', '', '', '', '', '1474626198_main_title_size.png'),
(51, 0, 6, 0, 1474627021, 22, 0, '42', 'Expire user เปิดเมนู Filter ที่เคยสร้างไว้', '46', '55', '22', '', '', '', '', '', ''),
(52, 0, 8, 0, 1474631483, 22, 0, '42', 'เก็บ Log ในส่วนสำคัญของการทำงาน', '52', '55', '22,20', 'วิเคราะห์ว่าได้ว่า สำคัญทุกส่วน ไว้ทำทีหลัง', '', '', '', '', ''),
(53, 0, 6, 0, 1474631511, 22, 0, '42', 'เก็บ Log ในส่วนสำคัญของการทำงาน', '46', '55', '22,20', 'เก็บเกือบทุกส่วน', '', '', '', '', ''),
(54, 0, 8, 0, 1474855201, 22, 0, '42', 'คู่มือ การใช้ ส่วนแจ้งปัญหา (มีเวลาค่อยทำ)', '46', '55', '22,20', '', '', '', '', '', ''),
(55, 0, 7, 0, 1474857597, 22, 0, '42', 'ครอบสิทธิ์ให้ subadmin ลบแต่ member ที่ตนเองสร้างเท่านั้น', '46', '55', '22,20', '', '', '', '', '', ''),
(56, 0, 8, 0, 1474966350, 22, 0, '42', 'ทำ limit loader ในเมนู GPS (mozer talk)', '49', '55', '22,20', 'limit loader ในเมนู GPS (mozer talk) เนื่องจากมีจำนวนสมาชิกในห้องเยอะ ทำให้บางครั้งแฮงค์ไป&nbsp;<br />\r\n** ทำแล้ว ดูตัวอย่างใน Edtalk<br />\r\n&nbsp;', '', '', '', '', '1474966824_gps_list1.png,1474966824_gps_list2.png'),
(57, 0, 6, 0, 1474967407, 19, 0, '42', 'ทำ limit loader ในเมนู GPS (mozer talk)', '46', '55', '22,20', 'limit loader ในเมนู GPS (mozer talk) เนื่องจากมีจำนวนสมาชิกในห้องเยอะ ทำให้บางครั้งแฮงค์ไป&nbsp;<br />\r\n** ทำแล้ว ดูตัวอย่างใน Edtalk<br />\r\n&nbsp;', '', '', '', '', '1474967404_gps_list1.png,1474967404_gps_list2.png'),
(58, 0, 8, 0, 1475750524, 22, 0, '42', 'แจ้งให้ Admin program ID ทราบว่าตนเองเข้า login ไม่ได้เพราะ โปรแกรมหมดอายุ', '46', '55', '', 'ในกรณี โปรแกรมไอดีหมดอายุ&nbsp;<br />\r\n- user mobile ไม่สามารถใช้งานได้<br />\r\n- admin program id ไม่สามารถเข้าหน้าจัดการ web ได้<br />\r\n&nbsp;', '', '', '', '', '');

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `app_entity_23`
--

DROP TABLE IF EXISTS `app_entity_23`;
CREATE TABLE IF NOT EXISTS `app_entity_23` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT '0',
  `parent_item_id` int(11) DEFAULT '0',
  `linked_id` int(11) DEFAULT '0',
  `date_added` int(11) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `sort_order` int(11) DEFAULT '0',
  `field_182` text NOT NULL,
  `field_183` text NOT NULL,
  `field_184` text NOT NULL,
  `field_185` text NOT NULL,
  `field_186` text NOT NULL,
  `field_194` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `app_entity_24`
--

DROP TABLE IF EXISTS `app_entity_24`;
CREATE TABLE IF NOT EXISTS `app_entity_24` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT '0',
  `parent_item_id` int(11) DEFAULT '0',
  `linked_id` int(11) DEFAULT '0',
  `date_added` int(11) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `sort_order` int(11) DEFAULT '0',
  `field_191` text NOT NULL,
  `field_192` text NOT NULL,
  `field_193` text NOT NULL,
  `field_195` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `app_fields`
--

DROP TABLE IF EXISTS `app_fields`;
CREATE TABLE IF NOT EXISTS `app_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `forms_tabs_id` int(11) NOT NULL,
  `type` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `short_name` varchar(64) DEFAULT NULL,
  `is_heading` tinyint(1) DEFAULT '0',
  `tooltip` text,
  `tooltip_display_as` varchar(16) NOT NULL DEFAULT '',
  `is_required` tinyint(1) DEFAULT '0',
  `required_message` text,
  `configuration` text,
  `sort_order` int(11) DEFAULT '0',
  `listing_status` tinyint(4) NOT NULL DEFAULT '0',
  `listing_sort_order` int(11) NOT NULL DEFAULT '0',
  `comments_status` tinyint(1) NOT NULL DEFAULT '0',
  `comments_sort_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_form_tabs_id` (`forms_tabs_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=201 ;

--
-- dump ตาราง `app_fields`
--

INSERT INTO `app_fields` (`id`, `entities_id`, `forms_tabs_id`, `type`, `name`, `short_name`, `is_heading`, `tooltip`, `tooltip_display_as`, `is_required`, `required_message`, `configuration`, `sort_order`, `listing_status`, `listing_sort_order`, `comments_status`, `comments_sort_order`) VALUES
(1, 1, 1, 'fieldtype_action', '', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, 1, 0, 0, 0),
(2, 1, 1, 'fieldtype_id', '', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, 1, 1, 0, 0),
(3, 1, 1, 'fieldtype_date_added', '', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, 0, 0, 0, 0),
(4, 1, 1, 'fieldtype_created_by', '', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, 0, 0, 0, 0),
(5, 1, 1, 'fieldtype_user_status', '', NULL, NULL, NULL, '', NULL, NULL, NULL, 0, 1, 7, 0, 0),
(6, 1, 1, 'fieldtype_user_accessgroups', '', NULL, NULL, NULL, '', NULL, NULL, NULL, 1, 1, 2, 0, 0),
(7, 1, 1, 'fieldtype_user_firstname', '', NULL, NULL, NULL, '', NULL, NULL, '{"allow_search":"1"}', 3, 1, 4, 0, 0),
(8, 1, 1, 'fieldtype_user_lastname', '', NULL, NULL, NULL, '', NULL, NULL, '{"allow_search":"1"}', 4, 1, 5, 0, 0),
(9, 1, 1, 'fieldtype_user_email', '', NULL, NULL, NULL, '', NULL, NULL, '{"allow_search":"1"}', 6, 1, 6, 0, 0),
(10, 1, 1, 'fieldtype_user_photo', '', NULL, NULL, NULL, '', NULL, NULL, NULL, 5, 0, 0, 0, 0),
(12, 1, 1, 'fieldtype_user_username', '', NULL, 1, NULL, '', NULL, NULL, '{"allow_search":"1"}', 2, 1, 3, 0, 0),
(13, 1, 1, 'fieldtype_user_language', '', NULL, 0, NULL, '', 0, NULL, NULL, 7, 0, 0, 0, 0),
(14, 1, 1, 'fieldtype_user_skin', '', NULL, 0, NULL, '', 0, NULL, NULL, 0, 0, 0, 0, 0),
(152, 21, 24, 'fieldtype_action', '', NULL, 0, NULL, '', 0, NULL, NULL, 0, 1, 0, 0, 0),
(153, 21, 24, 'fieldtype_id', '', NULL, 0, NULL, '', 0, NULL, NULL, 0, 1, 1, 0, 0),
(154, 21, 24, 'fieldtype_date_added', '', NULL, 0, NULL, '', 0, NULL, NULL, 0, 1, 6, 0, 0),
(155, 21, 24, 'fieldtype_created_by', '', NULL, 0, NULL, '', 0, NULL, NULL, 0, 1, 7, 0, 0),
(156, 21, 24, 'fieldtype_dropdown', 'Priority', NULL, 0, NULL, '', 1, NULL, '{"width":"input-medium"}', 0, 1, 2, 1, 0),
(157, 21, 24, 'fieldtype_dropdown', 'Status', NULL, 0, NULL, '', 1, NULL, '{"width":"input-medium"}', 1, 1, 4, 1, 1),
(158, 21, 24, 'fieldtype_input', 'Name', NULL, 1, NULL, '', 1, NULL, '{"allow_search":"1","width":"input-xlarge"}', 2, 1, 3, 0, 0),
(159, 21, 24, 'fieldtype_input_date', 'Start Date', NULL, 0, NULL, '', 0, NULL, NULL, 3, 1, 5, 0, 0),
(160, 21, 24, 'fieldtype_textarea_wysiwyg', 'Description', NULL, 0, NULL, '', 0, NULL, '{"allow_search":"1"}', 4, 0, 0, 0, 0),
(161, 21, 25, 'fieldtype_users', 'Team', NULL, 0, NULL, '', 0, NULL, '{"display_as":"checkboxes"}', 0, 0, 0, 0, 0),
(162, 21, 24, 'fieldtype_attachments', 'Attachments', NULL, 0, NULL, '', 0, NULL, NULL, 5, 0, 0, 0, 0),
(163, 22, 26, 'fieldtype_action', '', NULL, 0, NULL, '', 0, NULL, NULL, 0, 1, 0, 0, 0),
(164, 22, 26, 'fieldtype_id', '', NULL, 0, NULL, '', 0, NULL, NULL, 0, 1, 1, 0, 0),
(165, 22, 26, 'fieldtype_date_added', '', NULL, 0, NULL, '', 0, NULL, NULL, 0, 1, 10, 0, 0),
(166, 22, 26, 'fieldtype_created_by', '', NULL, 0, NULL, '', 0, NULL, NULL, 0, 1, 11, 0, 0),
(167, 22, 26, 'fieldtype_dropdown', 'Type', NULL, 0, NULL, '', 1, NULL, '{"width":"input-medium"}', 1, 1, 3, 0, 0),
(168, 22, 26, 'fieldtype_input', 'Name', NULL, 1, NULL, '', 1, NULL, '{"allow_search":"1","width":"input-xlarge"}', 2, 1, 4, 0, 0),
(169, 22, 26, 'fieldtype_dropdown', 'Status', NULL, 0, NULL, '', 1, NULL, '{"width":"input-large"}', 3, 1, 5, 1, 0),
(170, 22, 26, 'fieldtype_dropdown', 'Priority', NULL, 0, NULL, '', 1, NULL, '{"width":"input-medium"}', 4, 1, 2, 1, 1),
(171, 22, 26, 'fieldtype_users', 'Assigned To', NULL, 0, NULL, '', 0, NULL, '{"display_as":"checkboxes"}', 5, 1, 6, 0, 0),
(172, 22, 26, 'fieldtype_textarea_wysiwyg', 'Description', NULL, 0, NULL, '', 0, NULL, '{"allow_search":"1"}', 6, 0, 0, 0, 0),
(173, 22, 27, 'fieldtype_input_numeric', 'Est. Time', NULL, 0, NULL, '', 0, NULL, NULL, 1, 1, 7, 0, 0),
(174, 22, 27, 'fieldtype_input_numeric_comments', 'Work Hours', NULL, 0, NULL, '', 0, NULL, NULL, 2, 1, 8, 1, 2),
(175, 22, 27, 'fieldtype_input_date', 'Start Date', NULL, 0, NULL, '', 0, NULL, NULL, 3, 0, 0, 0, 0),
(176, 22, 27, 'fieldtype_input_date', 'End Date', NULL, 0, NULL, '', 0, NULL, NULL, 4, 1, 9, 0, 0),
(177, 22, 26, 'fieldtype_attachments', 'Attachments', NULL, 0, NULL, '', 0, NULL, NULL, 7, 0, 0, 0, 0),
(178, 23, 28, 'fieldtype_action', '', NULL, 0, NULL, '', 0, NULL, NULL, 0, 1, 0, 0, 0),
(179, 23, 28, 'fieldtype_id', '', NULL, 0, NULL, '', 0, NULL, NULL, 0, 1, 1, 0, 0),
(180, 23, 28, 'fieldtype_date_added', '', NULL, 0, NULL, '', 0, NULL, NULL, 0, 1, 6, 0, 0),
(181, 23, 28, 'fieldtype_created_by', '', NULL, 0, NULL, '', 0, NULL, NULL, 0, 1, 7, 0, 0),
(182, 23, 28, 'fieldtype_grouped_users', 'Department', NULL, 0, NULL, '', 1, NULL, NULL, 0, 1, 4, 1, 0),
(183, 23, 28, 'fieldtype_dropdown', 'Type', NULL, 0, NULL, '', 1, NULL, '{"width":"input-large"}', 2, 1, 2, 1, 1),
(184, 23, 28, 'fieldtype_input', 'Subject', NULL, 1, NULL, '', 1, NULL, '{"allow_search":"1","width":"input-xlarge"}', 3, 1, 3, 0, 0),
(185, 23, 28, 'fieldtype_textarea_wysiwyg', 'Description', NULL, 0, NULL, '', 0, NULL, '{"allow_search":"1"}', 4, 0, 0, 0, 0),
(186, 23, 28, 'fieldtype_dropdown', 'Status', NULL, 0, NULL, '', 1, NULL, '{"width":"input-large"}', 1, 1, 5, 1, 2),
(187, 24, 29, 'fieldtype_action', '', NULL, 0, NULL, '', 0, NULL, NULL, 0, 1, 0, 0, 0),
(188, 24, 29, 'fieldtype_id', '', NULL, 0, NULL, '', 0, NULL, NULL, 0, 1, 1, 0, 0),
(189, 24, 29, 'fieldtype_date_added', '', NULL, 0, NULL, '', 0, NULL, NULL, 0, 1, 4, 0, 0),
(190, 24, 29, 'fieldtype_created_by', '', NULL, 0, NULL, '', 0, NULL, NULL, 0, 1, 5, 0, 0),
(191, 24, 29, 'fieldtype_input', 'Name', NULL, 1, NULL, '', 1, NULL, '{"allow_search":"1","width":"input-xlarge"}', 1, 1, 3, 0, 0),
(192, 24, 29, 'fieldtype_textarea_wysiwyg', 'Description', NULL, 0, NULL, '', 0, NULL, '{"allow_search":"1"}', 2, 0, 0, 0, 0),
(193, 24, 29, 'fieldtype_dropdown', 'Status', NULL, 0, NULL, '', 0, NULL, '{"width":"input-medium"}', 0, 1, 2, 1, 0),
(194, 23, 28, 'fieldtype_attachments', 'Attachments', NULL, 0, NULL, '', 0, NULL, NULL, 5, 0, 0, 0, 0),
(195, 24, 29, 'fieldtype_attachments', 'Attachments', NULL, 0, NULL, '', 0, NULL, NULL, 3, 0, 0, 0, 0),
(196, 1, 1, 'fieldtype_parent_item_id', '', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, 1, 100, 0, 0),
(197, 21, 24, 'fieldtype_parent_item_id', '', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, 1, 100, 0, 0),
(198, 22, 26, 'fieldtype_parent_item_id', '', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, 1, 100, 0, 0),
(199, 23, 28, 'fieldtype_parent_item_id', '', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, 1, 100, 0, 0),
(200, 24, 29, 'fieldtype_parent_item_id', '', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, 1, 100, 0, 0);

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `app_fields_access`
--

DROP TABLE IF EXISTS `app_fields_access`;
CREATE TABLE IF NOT EXISTS `app_fields_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `access_groups_id` int(11) NOT NULL,
  `entities_id` int(11) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `access_schema` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_access_groups_id` (`access_groups_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `app_fields_choices`
--

DROP TABLE IF EXISTS `app_fields_choices`;
CREATE TABLE IF NOT EXISTS `app_fields_choices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `fields_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `is_default` tinyint(1) DEFAULT NULL,
  `bg_color` varchar(16) DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `users` text,
  PRIMARY KEY (`id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=68 ;

--
-- dump ตาราง `app_fields_choices`
--

INSERT INTO `app_fields_choices` (`id`, `parent_id`, `fields_id`, `name`, `is_default`, `bg_color`, `sort_order`, `users`) VALUES
(34, 0, 156, 'Urgent', 0, NULL, 1, NULL),
(35, 0, 156, 'High', 0, NULL, 2, NULL),
(37, 0, 157, 'New', 0, NULL, 1, NULL),
(38, 0, 157, 'Open', 0, NULL, 2, NULL),
(39, 0, 157, 'Waiting', 0, NULL, 3, NULL),
(40, 0, 157, 'Closed', 0, NULL, 4, NULL),
(41, 0, 157, 'Canceled', 0, NULL, 5, NULL),
(42, 0, 167, 'Task', 1, NULL, 1, NULL),
(43, 0, 167, 'Change', 0, NULL, 2, NULL),
(44, 0, 167, 'Bug', 0, '#ff7a00', 3, NULL),
(45, 0, 167, 'Idea', 0, NULL, 0, NULL),
(46, 0, 169, 'New', 1, NULL, 0, NULL),
(47, 0, 169, 'Open', 0, NULL, 2, NULL),
(48, 0, 169, 'Waiting', 0, NULL, 3, NULL),
(49, 0, 169, 'Done', 0, NULL, 4, NULL),
(50, 0, 169, 'Closed', 0, NULL, 5, NULL),
(51, 0, 169, 'Paid', 0, NULL, 6, NULL),
(52, 0, 169, 'Canceled', 0, NULL, 7, NULL),
(53, 0, 170, 'Urgent', 0, '#ff0000', 1, NULL),
(54, 0, 170, 'High', 0, NULL, 2, NULL),
(55, 0, 170, 'Medium', 1, NULL, 3, NULL),
(56, 0, 182, 'Support', 0, NULL, 0, ''),
(57, 0, 183, 'Request a Change', 0, NULL, 1, NULL),
(58, 0, 183, 'Report a Bug', 0, NULL, 2, NULL),
(59, 0, 183, 'Ask a Question', 0, NULL, 3, NULL),
(60, 0, 186, 'New', 1, NULL, 0, NULL),
(61, 0, 186, 'Open', 0, NULL, 2, NULL),
(62, 0, 186, 'Waiting On Client', 0, NULL, 3, NULL),
(63, 0, 186, 'Closed', 0, NULL, 4, NULL),
(64, 0, 186, 'Canceled', 0, NULL, 5, NULL),
(65, 0, 193, 'Open', 0, NULL, 1, NULL),
(66, 0, 193, 'Closed', 0, NULL, 2, NULL),
(67, 0, 193, 'New', 1, NULL, 0, NULL);

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `app_forms_tabs`
--

DROP TABLE IF EXISTS `app_forms_tabs`;
CREATE TABLE IF NOT EXISTS `app_forms_tabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `description` text NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=30 ;

--
-- dump ตาราง `app_forms_tabs`
--

INSERT INTO `app_forms_tabs` (`id`, `entities_id`, `name`, `description`, `sort_order`) VALUES
(1, 1, 'Info', '', 0),
(24, 21, 'Info', '', 0),
(25, 21, 'Team', '', 1),
(26, 22, 'Info', '', 0),
(27, 22, 'Time', '', 1),
(28, 23, 'Info', '', 0),
(29, 24, 'Info', '', 0);

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `app_global_lists`
--

DROP TABLE IF EXISTS `app_global_lists`;
CREATE TABLE IF NOT EXISTS `app_global_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `app_global_lists_choices`
--

DROP TABLE IF EXISTS `app_global_lists_choices`;
CREATE TABLE IF NOT EXISTS `app_global_lists_choices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `lists_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `is_default` tinyint(1) DEFAULT NULL,
  `bg_color` varchar(16) DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_lists_id` (`lists_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `app_related_items`
--

DROP TABLE IF EXISTS `app_related_items`;
CREATE TABLE IF NOT EXISTS `app_related_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL,
  `items_id` int(11) NOT NULL,
  `related_entities_id` int(11) NOT NULL,
  `related_items_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_related_entities_id` (`related_entities_id`),
  KEY `idx_related_items_id` (`related_items_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `app_reports`
--

DROP TABLE IF EXISTS `app_reports`;
CREATE TABLE IF NOT EXISTS `app_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `reports_type` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `menu_icon` varchar(64) NOT NULL DEFAULT '',
  `in_menu` tinyint(1) NOT NULL DEFAULT '0',
  `in_dashboard` tinyint(4) NOT NULL DEFAULT '0',
  `in_header` tinyint(1) NOT NULL DEFAULT '0',
  `dashboard_sort_order` int(11) DEFAULT NULL,
  `listing_order_fields` text NOT NULL,
  `users_groups` text,
  `parent_entity_id` int(11) NOT NULL DEFAULT '0',
  `parent_item_id` int(11) NOT NULL DEFAULT '0',
  `fields_in_listing` text,
  `rows_per_page` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_entity_id` (`parent_entity_id`),
  KEY `idx_parent_item_id` (`parent_item_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=106 ;

--
-- dump ตาราง `app_reports`
--

INSERT INTO `app_reports` (`id`, `parent_id`, `entities_id`, `created_by`, `reports_type`, `name`, `menu_icon`, `in_menu`, `in_dashboard`, `in_header`, `dashboard_sort_order`, `listing_order_fields`, `users_groups`, `parent_entity_id`, `parent_item_id`, `fields_in_listing`, `rows_per_page`) VALUES
(59, 0, 21, 0, 'default', '', '', 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0),
(61, 0, 22, 0, 'default', '', '', 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0),
(63, 0, 23, 0, 'default', '', '', 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0),
(66, 0, 21, 19, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0),
(67, 0, 1, 19, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0),
(68, 0, 21, 20, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0),
(69, 0, 22, 19, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 21, 1, NULL, 0),
(70, 0, 22, 19, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 21, 2, NULL, 0),
(71, 0, 22, 20, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 21, 1, NULL, 0),
(72, 0, 21, 21, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0),
(73, 0, 22, 19, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 21, 3, NULL, 0),
(74, 0, 22, 21, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 21, 3, NULL, 0),
(75, 76, 22, 21, 'standard', 'sss', '', 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0),
(76, 0, 21, 21, 'parent', '', '', 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0),
(77, 0, 21, 21, 'standard', 'ass', 'sssd', 1, 0, 0, NULL, '', NULL, 0, 0, NULL, 0),
(78, 0, 22, 20, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 21, 3, NULL, 0),
(79, 0, 22, 19, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 21, 4, NULL, 0),
(80, 0, 21, 24, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0),
(81, 0, 22, 24, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 21, 4, NULL, 0),
(82, 0, 21, 25, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0),
(83, 0, 22, 25, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 21, 4, NULL, 0),
(84, 0, 22, 20, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 21, 4, NULL, 0),
(85, 0, 21, 26, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0),
(86, 0, 22, 26, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 21, 3, NULL, 0),
(87, 0, 22, 26, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 21, 2, NULL, 0),
(88, 0, 22, 26, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 21, 1, NULL, 0),
(89, 0, 21, 22, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0),
(90, 0, 22, 22, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 21, 1, '163,170,167,168,177,169,171,165,166', 0),
(91, 0, 22, 19, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 21, 5, NULL, 0),
(92, 0, 22, 22, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 21, 5, NULL, 0),
(93, 94, 22, 22, 'standard', 'summary', 'envira', 1, 1, 1, NULL, '', NULL, 0, 0, NULL, 0),
(94, 0, 21, 22, 'parent', '', '', 0, 0, 0, NULL, '', NULL, 0, 0, NULL, 0),
(95, 0, 22, 22, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 21, 2, NULL, 0),
(96, 0, 22, 19, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 21, 6, NULL, 0),
(97, 0, 22, 22, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 21, 6, NULL, 0),
(98, 0, 24, 19, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 21, 6, NULL, 0),
(99, 0, 22, 19, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 21, 7, NULL, 0),
(100, 0, 22, 22, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 21, 7, NULL, 0),
(101, 0, 22, 19, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 21, 8, NULL, 0),
(102, 0, 22, 22, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 21, 8, NULL, 0),
(103, 0, 22, 20, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 21, 8, NULL, 0),
(104, 0, 22, 19, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 21, 9, NULL, 0),
(105, 0, 22, 20, 'entity', '', '', 0, 0, 0, NULL, '', NULL, 21, 9, NULL, 0);

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `app_reports_filters`
--

DROP TABLE IF EXISTS `app_reports_filters`;
CREATE TABLE IF NOT EXISTS `app_reports_filters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reports_id` int(11) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `filters_values` text NOT NULL,
  `filters_condition` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_reports_id` (`reports_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=113 ;

--
-- dump ตาราง `app_reports_filters`
--

INSERT INTO `app_reports_filters` (`id`, `reports_id`, `fields_id`, `filters_values`, `filters_condition`) VALUES
(68, 59, 157, '37,38,39', 'include'),
(70, 61, 169, '46,47,48', 'include'),
(72, 63, 186, '60,61,62', 'include'),
(73, 66, 157, '37,38,39', 'include'),
(74, 68, 157, '37,38,39', 'include'),
(75, 69, 169, '46,47,48', 'include'),
(76, 70, 169, '46,47,48', 'include'),
(77, 71, 169, '46,47,48,49', 'include'),
(78, 72, 157, '37,38,39,40,41', 'include'),
(79, 73, 169, '46,47,48,49', 'include'),
(80, 74, 169, '46,47,48,49,50', 'include'),
(81, 78, 169, '46,47,48', 'include'),
(82, 78, 171, '21', 'include'),
(83, 79, 169, '46,47,48', 'include'),
(84, 80, 157, '37,38,39', 'include'),
(85, 81, 169, '46,47,48,52', 'include'),
(86, 81, 171, '24', 'include'),
(87, 81, 166, '24', 'include'),
(88, 82, 157, '37,38,39', 'include'),
(89, 83, 169, '46,47,48', 'include'),
(90, 84, 169, '46,47,48', 'include'),
(91, 85, 157, '37,38,39', 'include'),
(92, 86, 169, '46,47,48', 'include'),
(93, 87, 169, '46,47,48', 'include'),
(94, 88, 169, '46,47,48', 'include'),
(95, 89, 157, '37,38,39', 'include'),
(96, 90, 169, '48', 'include'),
(97, 91, 169, '46,47,48', 'include'),
(98, 92, 169, '46,47,48', 'include'),
(99, 95, 169, '46,47,48', 'include'),
(100, 96, 169, '46,47,48', 'include'),
(102, 99, 169, '46,47,48', 'include'),
(103, 100, 169, '46,47,48,49', 'include'),
(104, 93, 171, '22', 'include'),
(105, 94, 161, '22', 'include'),
(106, 71, 171, '20', 'include'),
(107, 101, 169, '46,47,48', 'include'),
(108, 102, 169, '46,47,48', 'include'),
(109, 103, 169, '46,47,48,49', 'include'),
(110, 97, 169, '46,47,48', 'include'),
(111, 104, 169, '46,47,48', 'include'),
(112, 105, 169, '46,47,48', 'include');

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `app_sessions`
--

DROP TABLE IF EXISTS `app_sessions`;
CREATE TABLE IF NOT EXISTS `app_sessions` (
  `sesskey` varchar(32) NOT NULL,
  `expiry` int(11) unsigned NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`sesskey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- dump ตาราง `app_sessions`
--

INSERT INTO `app_sessions` (`sesskey`, `expiry`, `value`) VALUES
('8hmo3uk5gmh90t90acnb0dre00', 1484280528, 'uploadify_attachments|a:0:{}alerts|O:6:"alerts":1:{s:8:"messages";a:0:{}}app_send_to|N;app_current_version|s:5:"1.7.2";app_selected_items|a:0:{}app_logged_users_id|s:2:"22";'),
('hd0eqvesjhs79rh5b4bjl0cv70', 1480492700, 'uploadify_attachments|a:0:{}alerts|O:6:"alerts":1:{s:8:"messages";a:0:{}}app_send_to|N;app_current_version|s:0:"";app_selected_items|a:0:{}'),
('p94s91i6vfg215scfhg1cnkef4', 1477373206, 'uploadify_attachments|a:0:{}alerts|O:6:"alerts":1:{s:8:"messages";a:0:{}}app_send_to|N;app_current_version|s:5:"1.7.2";app_selected_items|a:1:{i:97;a:0:{}}app_logged_users_id|s:2:"22";'),
('r7h3dh07pq660l1kcu986e4826', 1475757185, 'uploadify_attachments|a:1:{i:177;a:0:{}}alerts|O:6:"alerts":1:{s:8:"messages";a:0:{}}app_send_to|a:1:{i:0;s:0:"";}app_selected_items|a:1:{i:102;a:0:{}}app_current_version|s:0:"";'),
('vu3o83tfo8q50qinq2e23g6213', 1476267129, 'uploadify_attachments|a:0:{}alerts|O:6:"alerts":1:{s:8:"messages";a:0:{}}app_send_to|N;app_current_version|s:0:"";app_selected_items|a:0:{}');

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `app_users_configuration`
--

DROP TABLE IF EXISTS `app_users_configuration`;
CREATE TABLE IF NOT EXISTS `app_users_configuration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `configuration_name` varchar(255) NOT NULL DEFAULT '',
  `configuration_value` text,
  PRIMARY KEY (`id`),
  KEY `idx_users_id` (`users_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- dump ตาราง `app_users_configuration`
--

INSERT INTO `app_users_configuration` (`id`, `users_id`, `configuration_name`, `configuration_value`) VALUES
(1, 22, 'sidebar-pos-option', 'page-sidebar-reversed'),
(2, 22, 'page-scale-option', 'page-scale-reduced'),
(3, 22, 'sidebar-option', '');

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `app_users_filters`
--

DROP TABLE IF EXISTS `app_users_filters`;
CREATE TABLE IF NOT EXISTS `app_users_filters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reports_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_reports_id` (`reports_id`),
  KEY `idx_users_id` (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `app_user_filters_values`
--

DROP TABLE IF EXISTS `app_user_filters_values`;
CREATE TABLE IF NOT EXISTS `app_user_filters_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filters_id` int(11) NOT NULL,
  `reports_id` int(11) NOT NULL,
  `fields_id` int(11) NOT NULL,
  `filters_values` text,
  `filters_condition` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_filters_id` (`filters_id`),
  KEY `idx_reports_id` (`reports_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
